'use-strict'

var community = document.querySelector('.story-community');
community.style.display = 'none';